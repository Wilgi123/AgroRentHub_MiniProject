# urls.py (main project file)
from agroapp import views  # Import views from your app
from django.contrib import admin
from django.urls import include, path
from django.conf import settings 
from django.conf.urls.static import static
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),  # Home page
    path('about_us/', views.about_us, name='about_us'),  # About Us page
    path('services/', views.services, name='services'),  # Services page
    path('contact/', views.contact, name='contact'),  # Contact page
    path('register/', views.register, name='register'),  # Register page
    path('verify_otp/', views.verify_otp, name='verify_otp'),
    path('check_email/', views.check_email, name='check_email'),
    path('login/', views.login_view, name='login'),  # Login page
    path('forgotpassword/', views.forgotpassword, name='forgotpassword'),
    path('resetpassword/<uidb64>/<token>/', views.resetpassword, name='resetpassword'),
    path('logout/', views.logout_view, name='logout'), 
    path("deliveryboy_index/", views.deliveryboy_index, name="deliveryboy_index"),
    path('social-auth/', include('social_django.urls', namespace='social')),
    
    path("customer_index/", views.customer_index, name="customer_index"),
    path('customer/customer_profile/', views.customer_profile, name='customer_profile'),
    path('customer/customer_about/', views.customer_about, name='customer_about'),
    path('customer/customer_service/', views.customer_service, name='customer_service'),
    path('customer/customer_profile/edit/', views.edit_details, name='edit_details'),
    path('customer/customer_profile/change_password/', views.change_password, name='change_password'),
    path('customer/products/', views.products, name='products'),
    path('add_to_cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('product_cart/', views.product_cart, name='product_cart'),
    path('productcart/', views.product_cart, name='productcart'),


    path("supplier_index/", views.supplier_index, name="supplier_index"),
    path('supplier_add_pro/', views.supplier_add_pro, name='supplier_add_pro'),
    path('supplier_add_pro/supplier_view_pro/', views.supplier_view_pro, name='supplier_view_pro'),
    path('supplier_view_pro/', views.supplier_view_pro, name='supplier_view_pro'),
    path('update_product/<int:product_id>/', views.update_product, name='update_product'),
    path('delete_product/<int:product_id>/', views.delete_product, name='delete_product'),
    path('supplier_add_cat/', views.supplier_add_cat, name='supplier_add_cat'),
    path('supplier_add_cat/supplier_view_cat/', views.supplier_view_cat, name='supplier_view_cat'),
    path('supplier_view_cat/', views.supplier_view_cat, name='supplier_view_cat'),
    path('update_category/<int:category_id>/', views.update_category, name='update_category'),
    path('delete_category/<int:category_id>/', views.delete_category, name='delete_category'),
    path('supplier/supplier_add_del/', views.supplier_add_del, name='supplier_add_del'),
    path('supplier/supplier_view_del/', views.supplier_view_del, name='supplier_view_del'),
    path('supplier/supplier_add_worker/', views.supplier_add_worker, name='supplier_add_worker'),
    path('supplier/supplier_view_worker/', views.supplier_view_worker, name='supplier_view_worker'),
    path('supplier/supplier_view_order/', views.supplier_view_order, name='supplier_view_order'),
    path('supplier/supplier_profile/', views.supplier_profile, name='supplier_profile'),
     path('supplier/edit-details/', views.supplier_edit_details, name='supplier_edit_details'),
    path('supplier/change-password/', views.supplier_change_password, name='supplier_change_password'),
    
    path("admin_index/", views.admin_index, name="admin_index"),
    path('admin_view_farmer/', views.admin_view_farmer, name='admin_view_farmer'),
    path('admin_view_supplier/', views.admin_view_supplier, name='admin_view_supplier'),
    path('admin_view_deliveryboy/', views.admin_view_deliveryboy, name='admin_view_deliveryboy'),
    path('admin_view_pro/', views.admin_view_pro, name='admin_view_pro'),
    path('admin_view_cat/', views.admin_view_cat, name='admin_view_cat'),
     path('toggle_user_status/<str:user_type>/<int:user_id>/', views.toggle_user_status, name='toggle_user_status'),
   # path('admin_view_worker/', views.admin_view_worker, name='admin_view_worker'),
   # path('admin_view_order/', views.admin_view_order, name='admin_view_order'),
 #   path('admin/admin_view_worker/', views.admin_view_worker, name='admin_view_worker'),
   # path('admin/admin_view_order/', views.admin_view_order, name='admin_view_order'),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
