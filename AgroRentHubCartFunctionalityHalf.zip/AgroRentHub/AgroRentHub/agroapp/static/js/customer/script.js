document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('nav ul li a');

    navLinks.forEach(link => {
        link.addEventListener('mouseover', () => {
            link.style.color = '#ffeb3b';
        });

        link.addEventListener('mouseout', () => {
            link.style.color = 'white';
        });
    });
});
/*document.addEventListener('DOMContentLoaded', function() {
    const contentBox = document.getElementById('content-box');
    const links = document.querySelectorAll('.sidenav a');

    const content = {
        about: `
            <h2>About Us</h2>
            <p>We are committed to providing the best agricultural rental services. Our mission is to support farmers by offering high-quality rental equipment.</p>
            <p>Our team is dedicated to helping you achieve your farming goals with our reliable and affordable rental solutions.</p>
        `,
        services: `
            <h2>Our Services</h2>
            <ul>
                <li>Tractor Rentals</li>
                <li>Harvesting Equipment</li>
                <li>Plowing Tools</li>
                <li>Seeding Machines</li>
                <li>Irrigation Systems</li>
            </ul>
            <p>We offer a wide range of services to meet your agricultural needs. Contact us to learn more about our services and how we can help you.</p>
        `,
        clients: `
            <h2>Our Clients</h2>
            <p>We are proud to have served a diverse group of clients, including small family farms and large agricultural enterprises.</p>
            <p>Our clients value our commitment to quality and our reliable service. Join our growing list of satisfied customers today.</p>
        `,
        contact: `
            <h2>Contact Us</h2>
            <p>We would love to hear from you! Reach out to us with any questions or to learn more about our services.</p>
            <p>Email: info@agrirent.com</p>
            <p>Phone: (123) 456-7890</p>
            <p>Address: 1234 Farm Lane, Agriculture City, AG 56789</p>
        `
    };

    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = e.target.getAttribute('data-content');
            contentBox.innerHTML = content[section];
        });
    });
});*/
