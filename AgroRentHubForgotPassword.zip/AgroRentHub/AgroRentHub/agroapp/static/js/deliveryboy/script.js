alert("Delivery Boy script loaded");
