from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.webdriver import WebDriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException  # Ensure this import is correct
from webdriver_manager.chrome import ChromeDriverManager
import pytest
import time

@pytest.fixture
def browser():
    chrome_options = Options()
    # chrome_options.add_argument("--headless")  # Ensure GUI is on
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    
    # Path to Brave Browser executable
    brave_path = r"C:\Users\wilgi\AppData\Local\BraveSoftware\Brave-Browser\Application\brave.exe"  # Use raw string for Windows paths
    chrome_options.binary_location = brave_path

    # Use WebDriver Manager to get the correct version of chromedriver
    service = Service(ChromeDriverManager().install())

    driver = webdriver.Chrome(service=service, options=chrome_options)
    driver.maximize_window()  # Maximize the window to full screen
    yield driver
    driver.quit()

def type_slowly(element, text, delay=0.1):
    """
    Type text into an input element with a delay between each keystroke.
    """
    for character in text:
        element.send_keys(character)
        time.sleep(delay)

def test_login_correct_credentials(browser: WebDriver):
    # Navigate to login page
    browser.get('http://localhost:8000/login')  # Replace with your local server URL

    # Find email and password fields
    email_field = browser.find_element(By.NAME, 'email')
    password_field = browser.find_element(By.NAME, 'password')
    
    # Enter login credentials slowly
    type_slowly(email_field, 'wilgimolthomas@gmail.com')
    type_slowly(password_field, 'Wilgi@123')

    # Submit the form
    password_field.send_keys(Keys.RETURN)

    # Verify successful login by checking for the presence of an element on the customer_index page
    assert 'customer_index' in browser.current_url  # Ensure you're redirected correctly

    # Slowly scroll down the page
    scroll_pause_time = 0.5  # Pause time between scrolls (in seconds)
    screen_height = browser.execute_script("return window.innerHeight;")
    scroll_height = browser.execute_script("return document.body.scrollHeight;")
    
    for i in range(0, scroll_height, screen_height):
        browser.execute_script(f"window.scrollTo(0, {i});")
        time.sleep(scroll_pause_time)
    
    # Optionally, wait for a few seconds at the end to observe the fully scrolled page
    time.sleep(2)

    # Verify that the entire page is scrolled by checking for an element at the bottom
    footer = browser.find_element(By.TAG_NAME, 'footer')
    assert footer.is_displayed()

def test_login_admin(browser: WebDriver):
    # Navigate to login page
    browser.get('http://localhost:8000/login')  # Replace with your local server URL

    # Find email and password fields
    email_field = browser.find_element(By.NAME, 'email')
    password_field = browser.find_element(By.NAME, 'password')
    
    # Enter admin login credentials slowly
    type_slowly(email_field, 'admin@gmail.com')
    type_slowly(password_field, 'admin@123')

    # Submit the form
    password_field.send_keys(Keys.RETURN)

    # Verify successful login by checking for the presence of an element on the admin_index page
    assert 'admin_index' in browser.current_url  # Ensure you're redirected correctly

    # Optionally, wait for a few seconds to observe the fully loaded page
    time.sleep(2)

def test_login_supplier(browser: WebDriver):
    # Navigate to login page
    browser.get('http://localhost:8000/login')  # Replace with your local server URL

    # Find email and password fields
    email_field = browser.find_element(By.NAME, 'email')
    password_field = browser.find_element(By.NAME, 'password')
    
    # Enter supplier login credentials slowly
    type_slowly(email_field, 'tiljithomas@gmail.com')
    type_slowly(password_field, 'Tilji@1234')

    # Submit the form
    password_field.send_keys(Keys.RETURN)

    # Verify successful login by checking for the presence of an element on the supplier_index page
    assert 'supplier_index' in browser.current_url  # Ensure you're redirected correctly

    # Optionally, wait for a few seconds to observe the fully loaded page
    time.sleep(2)

def test_login_deliveryboy(browser: WebDriver):
    # Navigate to login page
    browser.get('http://localhost:8000/login')  # Replace with your local server URL

    # Find email and password fields
    email_field = browser.find_element(By.NAME, 'email')
    password_field = browser.find_element(By.NAME, 'password')
    
    # Enter deliveryboy login credentials slowly
    type_slowly(email_field, 'jiltithomas@gmail.com')
    type_slowly(password_field, 'Jilti@123')

    # Submit the form
    password_field.send_keys(Keys.RETURN)

    # Verify successful login by checking for the presence of an element on the deliveryboy_index page
    assert 'deliveryboy_index' in browser.current_url  # Ensure you're redirected correctly

    # Optionally, wait for a few seconds to observe the fully loaded page
    time.sleep(2)


def test_login_incorrect_credentials(browser: WebDriver):
    # Navigate to login page
    browser.get('http://localhost:8000/login')  # Replace with your local server URL

    # Find email and password fields
    email_field = browser.find_element(By.NAME, 'email')
    password_field = browser.find_element(By.NAME, 'password')
    
    # Enter incorrect login credentials slowly
    type_slowly(email_field, 'wrongemail@example.com')
    type_slowly(password_field, 'WrongPassword')

    # Submit the form
    password_field.send_keys(Keys.RETURN)

    # Verify that the URL is still the login page
    assert 'login' in browser.current_url  # Ensure you're still on the login page

    # Look for the error message element without explicit waiting
    error_message = WebDriverWait(browser, 10).until(
    EC.visibility_of_element_located((By.CLASS_NAME, 'error-message'))
)

    # Assertions
    assert error_message.is_displayed()
    assert 'Invalid email or password' in error_message.text

    # Optionally, wait for a few seconds to observe the error message
    time.sleep(2)
