document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");

    function showError(input, message) {
        clearError(input);
        const errorDiv = document.createElement("div");
        errorDiv.className = "error-message";
        errorDiv.textContent = message;
        input.parentNode.insertBefore(errorDiv, input.nextSibling);
    }

    function clearError(input) {
        const errorDiv = input.parentNode.querySelector(".error-message");
        if (errorDiv) {
            errorDiv.remove();
        }
    }

    function validateProductName() {
        const input = document.getElementById("product_name");
        const value = input.value.trim();
        clearError(input);

        if (value.length < 3 || value.length > 100) {
            showError(input, "Product name must be between 3 to 100 characters.");
            return false;
        }

        if (!/^[a-zA-Z\s\-]+$/.test(value)) {
            showError(input, "Product name can only contain letters, spaces, and hyphens.");
            return false;
        }

        // Check for existing product name
        fetch(`/check_product_exists?name=${encodeURIComponent(value)}`)
            .then(response => response.json())
            .then(data => {
                if (data.exists) {
                    showError(input, "Product with this name already exists.");
                }
            });

        return true;
    }

    function validateProductPrice() {
        const input = document.getElementById("product_price_per_day");
        const value = parseFloat(input.value);
        clearError(input);

        if (isNaN(value) || value <= 0) {
            showError(input, "Please enter a valid price greater than zero.");
            return false;
        }

        if (value < 1 || value > 5000) {
            showError(input, "Price must be between Rs.1 and Rs.10,000.");
            return false;
        }

        return true;
    }

    function validateStockQuantity() {
        const input = document.getElementById("stock_quantity");
        const value = parseInt(input.value, 10);
        clearError(input);

        if (isNaN(value) || value < 0) {
            showError(input, "Please enter a valid non-negative integer for stock quantity.");
            return false;
        }

        if (value > 50) {
            showError(input, "Stock quantity cannot exceed 50 units.");
            return false;
        }

        return true;
    }

    function validateProductDescription() {
        const input = document.getElementById("product_description");
        const value = input.value.trim();
        clearError(input);

        if (value.length < 10 || value.length > 500) {
            showError(input, "Product description must be between 10 to 500 characters.");
            return false;
        }

        return true;
    }

    function validateCategory() {
        const select = document.getElementById("category");
        const value = select.value;
        clearError(select);

        if (!value) {
            showError(select, "Please select a category.");
            return false;
        }

        return true;
    }

    function validateProductImage() {
        const input = document.getElementById("product_image");
        const value = input.value;
        clearError(input);

        if (!value) {
            showError(input, "Please upload a product image.");
            return false;
        }

        return true;
    }

    document.getElementById("product_name").addEventListener("blur", validateProductName);
    document.getElementById("product_price_per_day").addEventListener("blur", validateProductPrice);
    document.getElementById("stock_quantity").addEventListener("blur", validateStockQuantity);
    document.getElementById("product_description").addEventListener("blur", validateProductDescription);
    document.getElementById("category").addEventListener("change", validateCategory);
    document.getElementById("product_image").addEventListener("change", validateProductImage);

    form.addEventListener("submit", function (event) {
        const isProductNameValid = validateProductName();
        const isProductPriceValid = validateProductPrice();
        const isStockQuantityValid = validateStockQuantity();
        const isProductDescriptionValid = validateProductDescription();
        const isCategoryValid = validateCategory();
        const isProductImageValid = validateProductImage();

        if (!isProductNameValid || !isProductPriceValid || !isStockQuantityValid || !isProductDescriptionValid || !isCategoryValid || !isProductImageValid) {
            event.preventDefault();
        }
    });
});

