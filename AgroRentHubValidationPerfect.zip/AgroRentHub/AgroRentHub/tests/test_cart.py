from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.webdriver import WebDriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, UnexpectedAlertPresentException
from webdriver_manager.chrome import ChromeDriverManager

import pytest
import time
import random

@pytest.fixture
def browser():
    chrome_options = Options()
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    
    # Path to Brave Browser executable
    brave_path = r"C:\Users\wilgi\AppData\Local\BraveSoftware\Brave-Browser\Application\brave.exe"
    chrome_options.binary_location = brave_path

    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)
    driver.maximize_window()
    yield driver
    driver.quit()

def type_slowly(element, text, delay=0.1):
    for character in text:
        element.send_keys(character)
        time.sleep(delay)

def test_cartFunctionality(browser: WebDriver):
    try:
        # Navigate to login page
        browser.get('http://localhost:8000/login')

        # Find email and password fields
        email_field = WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.NAME, 'email'))
        )
        password_field = browser.find_element(By.NAME, 'password')

        # Enter customer login credentials slowly
        type_slowly(email_field, 'wilgimolthomas@gmail.com')
        type_slowly(password_field, 'Wilgi@123')

        # Submit the form
        password_field.send_keys(Keys.RETURN)

        # Verify successful login
        WebDriverWait(browser, 10).until(
            EC.url_contains('customer_index')
        )

        # Navigate to the products page
        browser.get('http://localhost:8000/customer/products')

        # Debugging: Take a screenshot of the products page
        browser.save_screenshot('products_page.png')

        # Wait for all product images to be loaded
        product_images = WebDriverWait(browser, 10).until(
            EC.presence_of_all_elements_located((By.XPATH, '//div[@class="rental-item-image"]/a/img'))
        )

        # Choose a random product image
        random_product_image = random.choice(product_images)
        random_product_image.click()

        # Wait for the product details page to load
        WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, 'product-details-container'))
        )

        # Ensure that the page is fully loaded
        WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.NAME, 'quantity'))
        )

        # Automatically fill in the form fields with a delay
        quantity_field = WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.NAME, 'quantity'))
        )
        start_date_field = browser.find_element(By.NAME, 'start_date')
        end_date_field = browser.find_element(By.NAME, 'end_date')
        
        quantity_field.clear()
        type_slowly(quantity_field, '1', delay=0.2)
        start_date_field.clear()
        type_slowly(start_date_field, '2024-08-30', delay=0.2)
        end_date_field.clear()
        type_slowly(end_date_field, '2024-09-05', delay=0.2)

        # Wait for 5 seconds to observe the page
        time.sleep(5)

        # Click the "Add to Cart" button
        try:
            add_to_cart_button = WebDriverWait(browser, 10).until(
                EC.element_to_be_clickable((By.XPATH, '//button[text()="Add to Cart"]'))
            )
            add_to_cart_button.click()
        except UnexpectedAlertPresentException:
            alert = browser.switch_to.alert
            alert.accept()
            add_to_cart_button = WebDriverWait(browser, 10).until(
                EC.element_to_be_clickable((By.XPATH, '//button[text()="Add to Cart"]'))
            )
            add_to_cart_button.click()

        # Navigate to the cart page
        browser.get('http://localhost:8000/cart')

        # Verify the product is in the cart
        cart_item = WebDriverWait(browser, 10).until(
            EC.visibility_of_element_located((By.CLASS_NAME, 'cart-item'))
        )

        # Check for the presence of product details
        assert cart_item.find_element(By.CLASS_NAME, 'product-name').is_displayed()
        assert cart_item.find_element(By.CLASS_NAME, 'product-image').is_displayed()
        assert cart_item.find_element(By.CLASS_NAME, 'start-date').is_displayed()
        assert cart_item.find_element(By.CLASS_NAME, 'end-date').is_displayed()
        assert cart_item.find_element(By.CLASS_NAME, 'quantity').is_displayed()
        assert cart_item.find_element(By.CLASS_NAME, 'total-price').is_displayed()

        # Optionally, wait for a few seconds to observe the fully loaded cart page
        time.sleep(2)

    except Exception as e:
        print(f"An error occurred: {e}")
        browser.save_screenshot('error_screenshot.png')
        raise
