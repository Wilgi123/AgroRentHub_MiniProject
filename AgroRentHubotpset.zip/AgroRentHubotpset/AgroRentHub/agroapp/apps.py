from django.apps import AppConfig


class AgroappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'agroapp'
